<?php
session_start();
include 'auth.php'; // Ensure auth.php is included to access all functions

// Check if the user is logged in
if (!isset($_SESSION['user_email'])) {
    header("Location: index.php");
    exit();
}

// Debugging: Check the value returned by is_first_time_login
$user_email = $_SESSION['user_email'];
$is_first_time = is_first_time_login($user_email);
if (!$is_first_time) {
    header("Location: home.php");
    exit();
}

// Handle profile saving if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $avatar = $_FILES['avatar'];

    // Check if the file was uploaded without errors
    if ($avatar['error'] == UPLOAD_ERR_OK) {
        // Save the profile and mark the first login complete
        save_profile($username, $avatar);
        header("Location: home.php"); // Redirect after saving profile
        exit();
    } else {
        echo "Error uploading file.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Select Profile</title>
</head>
<body>
    <h2>Set Up Your Profile</h2>
    <form method="post" enctype="multipart/form-data">
        <label>Username:</label>
        <input type="text" name="username" required>
        <label>Avatar:</label>
        <input type="file" name="avatar">
        <button type="submit">Save Profile</button>
    </form>
</body>
</html>
