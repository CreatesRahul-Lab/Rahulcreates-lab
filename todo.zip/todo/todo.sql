CREATE DATABASE todo_app;

USE todo_app;

-- Users table to store user information
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Todos table to store tasks with a reminder date
CREATE TABLE todos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    task VARCHAR(255),
    status BOOLEAN DEFAULT FALSE,
    reminder_date DATE,  -- New column for reminder date
    FOREIGN KEY (user_id) REFERENCES users(id)
);
