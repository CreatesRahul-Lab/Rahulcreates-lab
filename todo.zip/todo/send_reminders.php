<?php
require 'vendor/autoload.php'; // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection (update with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_app"; // Replace with your database name

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get users with pending tasks that have a reminder date set and email not sent
$query = "SELECT users.email, GROUP_CONCAT(todos.task SEPARATOR ', ') AS pending_tasks, GROUP_CONCAT(todos.id SEPARATOR ',') AS task_ids
          FROM users
          JOIN todos ON users.id = todos.user_id
          WHERE todos.status = 'pending' AND todos.reminder_date = CURDATE() AND todos.email_sent = 0
          GROUP BY users.email";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Debugging: Log the query result
        error_log("Email: " . $row['email'] . " | Pending Tasks: " . $row['pending_tasks'] . " | Task IDs: " . $row['task_ids']);

        $to = $row['email'];
        $subject = "Pending Tasks Reminder";
        $message = "You have the following pending tasks: " . $row['pending_tasks'];

        // Send email using PHPMailer with Gmail SMTP
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.elasticemail.com'; // Verify this is the correct SMTP host
            $mail->SMTPAuth = true;
            $mail->Username = 'todolistwebapplicaation@gmail.com'; // Verify this is the correct email address
            $mail->Password = 'D1C65D25D8E41AB64E5C3F4F6781A1E9ACEB'; // Verify this is the correct password
            $mail->SMTPSecure = 'tls'; // Ensure this is the correct security setting
            $mail->Port = 2525; // Ensure this is the correct port

            //Recipients
            $mail->setFrom('todolistwebapplicaation@gmail.com', 'Todo App'); // Verify this is the correct sender email
            $mail->addAddress($to);

            //Content
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body    = $message;

            $mail->send();
            error_log("Email sent successfully to: " . $to); // Log successful email sending
            // Update email_sent status for all tasks
            $taskIds = $row['task_ids'];
            $conn->query("UPDATE todos SET email_sent = 1 WHERE id IN ($taskIds)");
        } catch (Exception $e) {
            error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        }
    }
} else {
    error_log("No pending tasks found or query failed.");
}

// Close database connection
$conn->close();
?>
