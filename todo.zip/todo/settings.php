<?php
session_start();

// Database connection (update with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_app"; // Replace with your database name

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$userId = $_SESSION['user_id']; // Get the logged-in user's ID

// Fetch user profile data
$query = "SELECT username, email FROM users WHERE id = $userId";
$result = $conn->query($query);
$user = $result ? $result->fetch_assoc() : null;

// Check if profile was updated successfully
$profileUpdated = false;
if (isset($_SESSION['profile_updated'])) {
    $profileUpdated = true;
    unset($_SESSION['profile_updated']); // Clear the session variable
}

// Handle form submissions for updating profile and password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = $conn->real_escape_string($_POST['username']);
        $email = $conn->real_escape_string($_POST['email']);
        $conn->query("UPDATE users SET username = '$username', email = '$email' WHERE id = $userId");
        $_SESSION['profile_updated'] = true; // Set session variable to indicate success
        header("Location: settings.php"); // Redirect to refresh page
    } elseif (isset($_POST['update_password'])) {
        $currentPassword = $conn->real_escape_string($_POST['current_password']);
        $newPassword = $conn->real_escape_string($_POST['new_password']);
        $confirmPassword = $conn->real_escape_string($_POST['confirm_password']);

        // Fetch the current password from the database
        $result = $conn->query("SELECT password FROM users WHERE id = $userId");
        $user = $result->fetch_assoc();

        // Verify the current password
        if (password_verify($currentPassword, $user['password'])) {
            if ($newPassword === $confirmPassword) {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $conn->query("UPDATE users SET password = '$hashedPassword' WHERE id = $userId");
                $_SESSION['profile_updated'] = true; // Set session variable to indicate success
                header("Location: settings.php"); // Redirect to refresh page
            } else {
                $error = "New passwords do not match.";
            }
        } else {
            $error = "Current password is incorrect.";
        }
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="homes.css">
    <style>
        body {
            background: url('https://c4.wallpaperflare.com/wallpaper/972/962/478/blue-simple-texture-gradient-wallpaper-preview.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .navbar {
            background-color: #343a40;
            
        }
        .navbar .navbar-brand, .navbar .nav-link {
            color: #ffffff;
           
        }
        .sidebar {
            background-color: #343a40;
            color: #ffffff;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #ffffff;
        }
        .sidebar .nav-link.active {
            background-color: #495057;
        }
        .profile-box {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .centered {
            text-align: center;
        }
        .centered-heading {
            text-align: center;
            width: 100%;
        }
        .white-text {
            color: #ffffff;
        }
        .logo {
            border-radius: 50%;
        }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark w-100">
        <a class="navbar-brand" href="profile.php">
            <img src="DALL·E 2024-11-01 19.16.55 - A high-resolution, modern and minimalistic logo for a to-do list web application, featuring a bold, clear checkmark within a simple, rounded notepad o.webp" alt="Todo App Logo" class="logo" style="height: 40px;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        User Options
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="profile.php">Profile</a>
                        <a class="dropdown-item" href="settings.php">Settings</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar">
                <div class="sidebar-sticky">
                    <h3 class="text-center">Menu</h3>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="home.php"><i class="fas fa-home"></i> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php"><i class="fas fa-user"></i> Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php"><i class="fas fa-cog"></i> Settings</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h2 class="h2 centered-heading white-text">User Setting</h2>
                </div>

                <div class="profile-box">
                    <?php if ($profileUpdated): ?>
                        <div class="alert alert-success">Profile updated successfully.</div>
                    <?php endif; ?>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="settings.php">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="update_profile">Update Profile</button>
                    </form>

                    <hr>

                    <div class="accordion" id="accordionExample">
                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <h2 class="mb-0">
                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Change Password
                                    </button>
                                </h2>
                            </div>

                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <form method="POST" action="settings.php">
                                        <div class="form-group">
                                            <label for="current_password">Current Password</label>
                                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="new_password">New Password</label>
                                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="confirm_password">Confirm New Password</label>
                                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary" name="update_password">Change Password</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <footer class="footer mt-auto py-3 bg-dark text-white text-center">
        <div class="container">
            <span>&copy; <?php echo date("Y"); ?> Todo App. All rights reserved.</span>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

