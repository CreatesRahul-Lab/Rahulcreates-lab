<?php
include 'db.php';

if (isset($_GET['task']) && isset($_GET['user'])) {
    $task_id = $_GET['task'];
    $user_id = $_GET['user'];
    $query = "DELETE FROM todos WHERE task = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $task_id, $user_id);
    $stmt->execute();

    header("Location: manage_tasks.php");
}
?>
