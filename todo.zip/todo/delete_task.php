<?php
// Include database connection file
include 'config.php';

if (isset($_POST['task_id'])) {
    $taskId = $_POST['task_id'];

    // Prepare and execute the delete statement
    $sql = "DELETE FROM todos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $taskId);

    if ($stmt->execute()) {
        echo "Task deleted successfully.";
    } else {
        echo "Error deleting task: " . $stmt->error;
    }

    $stmt->close();
    header("Location: home.php"); // Redirect to home.php
    exit(); // Ensure no further code is executed
} else {
    echo "No task ID received.";
}

$conn->close();
?>
