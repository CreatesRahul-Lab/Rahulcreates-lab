<?php
// add_task.php

// Include your database connection
include 'db.php';

// Check if the form data is sent via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $task = $_POST['task'];
    $due_date = $_POST['due_date'] ?? null; // Handle optional due date

    // Insert task into the database
    $query = "INSERT INTO todos (task, due_date, status) VALUES (?, ?, 0)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $task, $due_date);
    $stmt->execute();

    // Fetch updated list of tasks to display in the table
    $result = $conn->query("SELECT * FROM todos ORDER BY id DESC");

    // Output the updated table rows
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['task']) . "</td>
                <td>" . htmlspecialchars($row['due_date'] ?? 'None') . "</td>
                <td>" . ($row['status'] ? 'Completed' : 'Pending') . "</td>
                <td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='id' value='" . $row['id'] . "'>
                        <input type='hidden' name='status' value='" . ($row['status'] ? 0 : 1) . "'>
                        <button type='submit' name='update' style='cursor: pointer;'>" . ($row['status'] ? 'Mark as Pending' : 'Mark as Completed') . "</button>
                    </form>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='id' value='" . $row['id'] . "'>
                        <button type='submit' name='delete' style='cursor: pointer;'>Delete</button>
                    </form>
                </td>
            </tr>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
