<?php
include 'db.php';

$query = "SELECT task, user_id, due_date, status FROM todos";
$result = $conn->query($query);

echo "<h2>Manage Tasks</h2>";
while ($row = $result->fetch_assoc()) {
    echo "Task ID: " . $row['task'] . "<br>";
    echo "User ID: " . $row['user_id'] . "<br>";
    echo "Due Date: " . $row['due_date'] . "<br>";
    echo "Status: " . $row['status'] . "<br>";
    echo "<a href='edit_admin.php?task=" . $row['task'] . "&user=" . $row['user_id'] . "'>Edit</a> | ";
    echo "<a href='delete_admin.php?task=" . $row['task'] . "&user=" . $row['user_id'] . "'>Delete</a><br><br>";
}
?>
