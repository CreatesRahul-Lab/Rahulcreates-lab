<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List Interface</title>
    <link rel="stylesheet" href="homies.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav>
                <ul>
                    <li>Home</li>
                    <li>Tasks</li>
                    <li>Deadlines</li>
                    <li>Notes</li>
                    <!-- Add more items as needed -->
                </ul>
            </nav>
        </aside>

        <!-- Main content -->
        <main class="content">
            <!-- Header with logo and title -->
            <header>
                <div class="logo">DG</div>
                <h1>To-Do-List</h1>
                <p>By Mockup Creations</p>
            </header>

            <!-- Task List Table -->
            <div class="task-table">
                <div class="task-row header">
                    <div>#</div>
                    <div>Task</div>
                    <div>Deadline</div>
                    <div>Status</div>
                </div>
                <!-- Task items (repeatable rows) -->
                <div class="task-row">
                    <div>1</div>
                    <div>To-Do Item</div>
                    <div>Due 10</div>
                    <div><input type="checkbox"></div>
                </div>
                <div class="task-row">
                    <div>2</div>
                    <div>Privacy Task</div>
                    <div>Due 21</div>
                    <div><input type="checkbox"></div>
                </div>
                <!-- Add more rows as needed -->
            </div>

            <!-- Task Input Form -->
            <div class="task-input">
                <input type="text" placeholder="New Task">
                <input type="date">
                <button>Add Task</button>
            </div>
        </main>
    </div>

    <!-- New Task Button -->
    <button class="new-task">+ New Task</button>

</body>
</html>
