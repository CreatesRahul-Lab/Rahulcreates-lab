<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Admin Dashboard HTML
echo "<h1>Admin Dashboard</h1>";
echo "<a href='manage_users.php'>Manage Users</a><br>";
echo "<a href='manage_tasks.php'>Manage Tasks</a><br>";
echo "<a href='logout.php'>Logout</a>";
?>
