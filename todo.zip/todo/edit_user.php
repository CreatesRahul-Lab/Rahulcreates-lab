<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT email FROM users WHERE id = $id";
    $result = $conn->query($query);
    $user = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
    $email = $_POST['email'];
    $query = "UPDATE users SET email = '$email' WHERE id = $id";
    if ($conn->query($query) === TRUE) {
        echo "User updated successfully.";
    } else {
        echo "Error updating user: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>
    <h2>Edit User</h2>
    <form method="post" action="">
        Email: <input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>
        <input type="submit" name="update" value="Update">
    </form>
    <a href="manage_users.php">Back to Manage Users</a>
</body>
</html>
