<?php
include 'config.php'; // Database connection

if (isset($_POST['task_id']) && isset($_POST['status'])) {
    $taskId = $_POST['task_id'];
    $newStatus = $_POST['status'];

    // Prepare and execute the update statement
    $sql = "UPDATE todos SET status = ?, updated_at = NOW() WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $newStatus, $taskId);

    if ($stmt->execute()) {
        echo "Task status updated successfully.";
    } else {
        echo "Error updating task status: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();

// Redirect back to home.php
header("Location: home.php");
exit();
?>
