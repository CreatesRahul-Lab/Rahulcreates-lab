<?php
include 'db.php';

if (isset($_GET['task']) && isset($_GET['user'])) {
    $task_id = $_GET['task'];
    $user_id = $_GET['user'];
    $query = "SELECT task, user_id, due_date, status FROM todos WHERE task = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $task_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $task = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $task_id = $_POST['task_id'];
    $user_id = $_POST['user_id'];
    $task = $_POST['task'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];

    $query = "UPDATE todos SET task = ?, due_date = ?, status = ? WHERE task = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssii", $task, $due_date, $status, $task_id, $user_id);
    $stmt->execute();

    header("Location: manage_tasks.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
</head>
<body>
    <h2>Edit Task</h2>
    <form method="POST" action="edit_admin.php">
        <input type="hidden" name="task_id" value="<?php echo $task['task']; ?>">
        <input type="hidden" name="user_id" value="<?php echo $task['user_id']; ?>">
        Task: <input type="text" name="task" value="<?php echo $task['task']; ?>"><br>
        Due Date: <input type="date" name="due_date" value="<?php echo $task['due_date']; ?>"><br>
        Status: <input type="text" name="status" value="<?php echo $task['status']; ?>"><br>
        <input type="submit" value="Update Task">
    </form>
</body>
</html>
