<?php
session_start(); 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_app"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

$userId = $_SESSION['user_id']; 

$pendingTasksQuery = "SELECT COUNT(*) AS pending_count FROM todos WHERE status = 0 AND user_id = $userId"; 
$pendingTasksResult = $conn->query($pendingTasksQuery);
$pendingCount = $pendingTasksResult ? $pendingTasksResult->fetch_assoc()['pending_count'] : 0;

$query = "SELECT id, task, status, due_date FROM todos WHERE user_id = $userId"; 
$result = $conn->query($query);
$todos = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add']) && !empty($_POST['task'])) {
        $task = $conn->real_escape_string($_POST['task']);
        $due_date = !empty($_POST['due_date']) ? "'" . $conn->real_escape_string($_POST['due_date']) . "'" : "NULL";
        $conn->query("INSERT INTO todos (task, status, due_date, user_id) VALUES ('$task', 0, $due_date, $userId)"); 
        header("Location: home.php"); 
    }

    if (isset($_POST['update']) && isset($_POST['id']) && isset($_POST['status'])) {
        $id = (int)$_POST['id'];
        $status = (int)$_POST['status'];
        $conn->query("UPDATE todos SET status = $status WHERE id = $id AND user_id = $userId"); 
        header("Location: home.php"); 
    }

    if (isset($_POST['delete']) && isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        $conn->query("DELETE FROM todos WHERE id = $id AND user_id = $userId"); 
        header("Location: home.php"); 
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Todo List</title>
    <link rel="stylesheet" href="home.css">
  
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            display: flex;
            font-family: Arial, sans-serif;
            margin: 0;
            transition: background-color 0.3s, color 0.3s;
        }

        
        footer {
            background-color: #252539;
            color: #ffffff;
            transition: background-color 0.3s, color 0.3s;
        }

        table th {
            background-color: #555580;
            color: #dcdcdc;
        }

        table th:hover {
            background-color: #ff8c00;
        }

        .quote-container {
            text-align: center;
            font-style: italic;
            color: #ff8c00;
            font-size: 1.2em;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px;
            box-shadow: 0px 0px 10px rgba(255, 165, 0, 0.2);
        }

        @keyframes rotateQuotes {
            0% { opacity: 0; content: "The secret of getting ahead is getting started."; }
            25% { opacity: 1; }
            33% { opacity: 0; }
            34% { content: "Do not wait to strike till the iron is hot, but make it hot by striking."; }
            58% { opacity: 1; }
            66% { opacity: 0; }
            67% { content: "Well planned is half done."; }
            92% { opacity: 1; }
            100% { opacity: 0; }
        }

        .quote-container::before {
            content: "";
            animation: rotateQuotes 15s infinite;
            display: block;
        }

        .btn-completed, .btn-pending {
            background-color: green;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .btn-delete {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .sidebar {
            width: 200px;
            background-color: #333;
            color: white;
            padding: 15px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            transition: width 0.3s ease;
            z-index: 2;
        }
        .sidebar.collapsed {
            width: 60px;
        }
        .sidebar h3, .sidebar a {
            display: block;
            white-space: nowrap;
            overflow: hidden;
            transition: opacity 0.3s ease;
        }
        .sidebar.collapsed h3, .sidebar.collapsed a {
            opacity: 0;
        }
        .toggle-sidebar {
            color: white;
            cursor: pointer;
            text-align: center;
            padding: 10px 0;
            display: block;
            width: 100%;
            border-top: 1px solid #444;
            border-bottom: 1px solid #444;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 0;
        }

        .navbar {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            position: fixed;
            top: 0;
            left: 200px;
            width: calc(100% - 200px);
            z-index: 1;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .sidebar.collapsed ~ .navbar {
            left: 60px;
            width: calc(100% - 60px);
        }
        .navbar h2 {
            margin: 0;
            flex-grow: 1;
            text-align: center;
        }
        .navbar .logout {
            position: relative;
            margin-left: auto;
            color: white;
            text-decoration: none;
            padding: 0 15px;
        }

        .main-content {
            margin-left: 250px;
            padding: 80px 20px 20px;
            width: calc(100% - 200px);
            transition: margin-left 0.3s ease, width 0.3s ease;
            min-height: 100vh;
            overflow-y: auto;
            position: static;
            margin-top: 600px;
        }
        .sidebar.collapsed ~ .main-content {
            margin-left: 60px;
            width: calc(100% - 60px);
        }

        footer {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 200px;
            width: calc(100% - 200px);
            transition: left 0.3s ease, width 0.3s ease;
            z-index: 1;
        }
        .sidebar.collapsed ~ footer {
            left: 60px;
            width: calc(100% - 60px);
        }

        table th {
            background-color: #007bff;
            color: white;
            border: none;
        }
        table th:hover {
            background-color: #007bff;
        }

        .quote-container {
            text-align: center;
            font-style: italic;
            color: #333;
            font-size: 1.2em;
            position: fixed;
            bottom: 40px;
            left: 0;
            width: 100%;
            padding: 10px;
            z-index: 0;
            margin-left: 110px;
        }

        @keyframes rotateQuotes {
            0% { opacity: 0; content: "The secret of getting ahead is getting started."; }
            25% { opacity: 1; }
            33% { opacity: 0; }
            34% { content: "Do not wait to strike till the iron is hot, but make it hot by striking."; }
            58% { opacity: 1; }
            66% { opacity: 0; }
            67% { content: "Well planned is half done."; }
            92% { opacity: 1; }
            100% { opacity: 0; }
        }

        .quote-container::before {
            content: "";
            animation: rotateQuotes 15s infinite;
            display: block;
        }

        .avatar-circle {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            overflow: hidden;
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .avatar-circle img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="avatar-circle">
            <img src="uploads/avatars/<?php echo $_SESSION['avatar']; ?>" alt="Avatar">
        </div>
    </div>

    <div style="background-color: #ffcc00; color: #333; padding: 10px; text-align: center; position: fixed; top: 700px; right: 10px; z-index: 3;">
        You have <?php echo $pendingCount; ?> pending task(s) to complete!
    </div>

    <div class="sidebar" id="sidebar">
        <h3>Menu</h3>
        <a href="home.php">Home</a>
        <a href="profile.php">Profile</a>
        <a href="settings.php">Settings</a>
        <span class="toggle-sidebar" onclick="toggleSidebar()">Toggle</span>
    </div>

    <div class="navbar">
        <h2>Todo List Application</h2>
        <div class="avatar-circle">
            <img src="uploads/avatars/<?php echo $_SESSION['avatar']; ?>" alt="Avatar">
        </div>
        <button onclick="toggleTheme()" style="cursor: pointer;">Toggle Theme</button>
    </div>

    <div class="main-content">
        <h3>Add New Task</h3>
        <form method="post">
            <input type="text" name="task" required placeholder="Enter task">
            <input type="date" name="due_date" placeholder="Due date"> 
            <button type="submit" name="add" style="cursor: pointer;">Add</button>
        </form>
        <table>
            <thead>
                <tr>
                    <th>Task</th>
                    <th>Due Date</th> 
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (is_array($todos)) {
                    foreach ($todos as $row) { ?>
                        <tr>
    <td><?php echo htmlspecialchars($row['task']); ?></td>
    <td><?php echo htmlspecialchars($row['due_date'] ?? 'None'); ?></td> 
    <td><?php echo $row['status'] === 'completed' ? 'Completed' : 'Pending'; ?></td> 
    <td>
        <form method="post" action="update_task.php" style="display:inline;">
            <input type="hidden" name="task_id" value="<?php echo $row['id']; ?>">
            <input type="hidden" name="status" value="<?php echo $row['status'] === 'completed' ? 'pending' : 'completed'; ?>">
            <button type="submit" class="btn-completed" style="background-color: green";>
                <?php echo $row['status'] === 'completed' ? 'Mark as Pending' : 'Mark as Completed'; ?>
            </button>
        </form>
        <form method="post" action="delete_task.php" style="display:inline;">
            <input type="hidden" name="task_id" value="<?php echo $row['id']; ?>">
            <button type="submit" class="btn-delete"   style="background-color: red";>Delete</button>
        </form>
    </td>
</tr>

                    <?php }
                } ?>
            </tbody>
        </table>
    </div>

    <div class="quote-container"></div>

    <footer>
        <p>&copy; 2024 Your Company. All rights reserved.</p>
    </footer>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("collapsed");
            document.querySelector(".navbar").classList.toggle("collapsed");
            document.querySelector(".main-content").classList.toggle("collapsed");
        }

        function toggleTheme() {
            document.body.classList.toggle("dark-mode");
            const isDarkMode = document.body.classList.contains("dark-mode");
            localStorage.setItem("darkMode", isDarkMode ? "enabled" : "disabled");
        }

        function loadTheme() {
            const darkMode = localStorage.getItem("darkMode");
            if (darkMode === "enabled") {
                document.body.classList.add("dark-mode");
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            loadTheme();
        });
    </script>
</body>
</html>