<?php
include 'auth.php';

if (is_logged_in()) {
    header("Location: home.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    if (signup($email, $password)) {
        header("Location: login.php");
        exit();
    } else {
        $error = "Signup failed";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .footer {
            background-color: black;
            color: whitesmoke;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="signup-form">
            <h2>Sign Up</h2>
            <form method="post">
                <label>Email:</label>
                <input type="email" name="email" required>
                <label>Password:</label>
                <input type="password" name="password" required>
                <button type="submit">Sign Up</button>
            </form>
            
            <p>Already have an account? <a href="login.php">Login</a></p>
            <?php if (isset($error)) echo "<p>$error</p>"; ?>
        </div>
        <div class="image-container">
            <!-- Background image as per the design -->
        </div>
    </div>

   <div class="footer">
        <p>&copy; 2024 Todo App</p> 
   </div>

</body>
</html>
