<?php
// process_forgot_password.php
require 'db.php'; // Ensure you have a db.php for database connection

if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate a unique reset token
        $token = bin2hex(random_bytes(50));

        // Save the token to the database
        $stmt = $conn->prepare("UPDATE users SET password_reset_token = ? WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        $stmt->execute();

        // Show the token to the user
        echo "Your reset token is: " . htmlspecialchars($token);
        echo "<br><a href='reset_password.php?token=" . htmlspecialchars($token) . "'>Reset Password</a>";
    } else {
        echo "No account found with that email.";
    }
}
?>
