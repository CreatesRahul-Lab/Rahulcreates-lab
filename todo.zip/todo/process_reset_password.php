<?php
// process_reset_password.php
require 'db.php'; // Ensure you have a db.php for database connection

if (isset($_POST['token']) && isset($_POST['new_password'])) {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Find the user with this token
    $stmt = $conn->prepare("SELECT * FROM users WHERE password_reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the password and clear the reset token
        $stmt = $conn->prepare("UPDATE users SET password = ?, password_reset_token = NULL WHERE password_reset_token = ?");
        $stmt->bind_param("ss", $new_password, $token);
        $stmt->execute();

        echo "Your password has been successfully reset. Now you can login with new password";
        header("Location: login.php");
        exit();
    } else {
        echo "Invalid or expired token.";
    }

    
}
?>

