<?php
include 'db.php';

$query = "SELECT id, email FROM users";
$result = $conn->query($query);

echo "<h2>Manage Users</h2>";
while ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . "<br>";
    
    echo "Email: " . $row['email'] . "<br>";
    echo "<a href='edit_user.php?id=" . $row['id'] . "'>Edit</a> | ";
    echo "<a href='delete_user.php?id=" . $row['id'] . "'>Delete</a><br><br>";
}
?>
