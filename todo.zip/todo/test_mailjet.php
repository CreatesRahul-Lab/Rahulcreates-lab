<?php
require 'vendor/autoload.php'; // Load Mailjet

use \Mailjet\Resources;
use \Mailjet\Client;

// Create a new Mailjet instance
$mj = new \Mailjet\Client('YOUR_MAILJET_API_KEY', 'YOUR_MAILJET_SECRET_KEY', true, ['version' => 'v3.1']);

// Define email parameters
$to = "recipient@example.com"; // Replace with a test recipient email
$subject = "Test Email";
$message = "This is a test email sent using Mailjet.";
$fromEmail = "your-email@gmail.com"; // Replace with your sender email
$fromName = "Test Sender";

// Send email using Mailjet
$body = [
    'Messages' => [
        [
            'From' => [
                'Email' => $fromEmail,
                'Name' => $fromName
            ],
            'To' => [
                [
                    'Email' => $to,
                    'Name' => "Recipient"
                ]
            ],
            'Subject' => $subject,
            'TextPart' => $message
        ]
    ]
];

try {
    $response = $mj->post(Resources::$Email, ['body' => $body]);
    if ($response->success()) {
        echo "Test email sent successfully!";
    } else {
        echo "Failed to send test email. Response: " . json_encode($response->getData());
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
