<?php
session_start();
include 'db.php';

if (isset($_POST['theme'])) {
    $theme = $_POST['theme'];
    $userId = $_SESSION['user_id']; // Assuming user ID is in session

    // Prepare the SQL statement
    $sql = "UPDATE users SET theme = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    // Bind parameters
    $stmt->bind_param("si", $theme, $userId);

    // Execute the statement
    if ($stmt->execute() === false) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }

    // Close the statement
    $stmt->close();

    // Update session theme
    $_SESSION['theme'] = $theme;

    // Redirect to home page
    header("Location: home.php");
    exit();
}
?>