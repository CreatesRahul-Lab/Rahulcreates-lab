<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <style>
        /* Basic reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Background and gradient overlay */
        body {
            font-family: Arial, sans-serif;
            background-image: url('AlbedoBase_XL_A_visually_stunning_todolist_web_application_ima_2.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            color: #fff;
            overflow: hidden;
            position: relative;
        }

        /* Animated gradient overlay */
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(120deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.8));
            z-index: -1;
            animation: gradient 8s infinite alternate;
        }

        @keyframes gradient {
            0% { background: linear-gradient(120deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.8)); }
            100% { background: linear-gradient(120deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.6)); }
        }

        /* Floating shapes */
        .floating-shapes div {
            position: absolute;
            border-radius: 50%;
            opacity: 0.3;
            background: rgba(255, 255, 255, 0.5);
            animation: float 6s ease-in-out infinite;
        }

        .floating-shapes .circle1 {
            width: 80px;
            height: 80px;
            top: 10%;
            left: 15%;
            animation-delay: 0s;
        }

        .floating-shapes .circle2 {
            width: 100px;
            height: 100px;
            top: 30%;
            right: 10%;
            animation-delay: 2s;
        }

        .floating-shapes .circle3 {
            width: 120px;
            height: 120px;
            bottom: 20%;
            left: 25%;
            animation-delay: 4s;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        /* Navbar styling */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            background: rgba(0, 0, 0, 0.7);
        }

        .navbar img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        .navbar h1 {
            font-size: 1.5rem;
        }

        .navbar ul {
            list-style: none;
            display: flex;
        }

        .navbar ul li {
            margin-left: 1.5rem;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .navbar ul li a:hover {
            color: #ffcc00;
        }

        /* Content section */
        .content {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 80vh;
            text-align: center;
            padding: 0 2rem;
        }

        .content h2 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.8);
        }

        .content p {
            font-size: 1.2rem;
            line-height: 1.6;
            max-width: 600px;
            margin-bottom: 2rem;
        }

        .btn-primary {
            padding: 0.8rem 2rem;
            font-size: 1rem;
            color: #fff;
            background-color: #ff6f61;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .btn-primary:hover {
            background-color: #ff3e2f;
        }

        /* Footer styling */
        .footer {
            background: rgba(0, 0, 0, 0.7);
            padding: 1rem;
            text-align: center;
            margin-top: 31px;
        }

        .footer p {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

    <!-- Floating shapes -->
    <div class="floating-shapes">
        <div class="circle1"></div>
        <div class="circle2"></div>
        <div class="circle3"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar">
        
        <img src="DALL·E 2024-11-01 19.16.55 - A high-resolution, modern and minimalistic logo for a to-do list web application, featuring a bold, clear checkmark within a simple, rounded notepad o.webp" alt="">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="About.html">About</a></li>
            <li><a href="Service.html">Services</a></li>
            <li><a href="http://localhost/todoPhp/contact.php" target="_blank">Contact</a></li>
        </ul>
    </nav>

    <!-- Content Section -->
    <div class="content">
        <h2>Welcome to Your To-Do List</h2>
        <p>Manage your tasks effortlessly with our intuitive and efficient to-do list application.</p>
        <a href="http://localhost/todoPhp/signup.php" class="btn-primary">Get Started</a>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 Your Company. All rights reserved.</p>
    </footer>

</body>
</html>
