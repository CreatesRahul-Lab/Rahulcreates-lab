<?php
session_start();
include 'db.php';

function signup($email, $password) {
    global $conn;

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $avatarPath = null;

    if (!empty($_FILES['avatar']['name'])) {
        $avatarFile = $_FILES['avatar'];
        $avatarExtension = pathinfo($avatarFile['name'], PATHINFO_EXTENSION);
        $avatarFilename = uniqid() . '.' . $avatarExtension;
        $uploadDir = 'uploads/avatars/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $avatarPath = $uploadDir . $avatarFilename;
        move_uploaded_file($avatarFile['tmp_name'], $avatarPath);
    }

    $stmt = $conn->prepare("INSERT INTO users (email, password, avatar, first_time_login) VALUES (?, ?, ?, TRUE)");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("sss", $email, $hashed_password, $avatarPath);
    return $stmt->execute();
}

function login($email, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, password, avatar, first_time_login FROM users WHERE email = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password, $avatar, $first_time_login);
        $stmt->fetch();
        
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_email'] = $email;
            $_SESSION['avatar'] = $avatar;

            if ($first_time_login) {
                return true;
            }
            return false;
        }
    }
    
    return false;
}

function save_profile($username, $avatar) {
    global $conn;
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("UPDATE users SET username = ?, avatar = ?, first_time_login = FALSE WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("ssi", $username, $avatar, $user_id);
    $stmt->execute();

    $_SESSION['avatar'] = $avatar;
}

function mark_first_login_complete($user_id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE users SET first_time_login = FALSE WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
}

function is_first_time_login($email) {
    // Implement the logic to check if it's the user's first time login
    // Return true if it is, false otherwise
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function logout() {
    session_destroy();
}
?>
