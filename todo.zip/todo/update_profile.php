<?php
session_start();

// Database connection (update with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo_app"; // Replace with your database name

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$userId = $_SESSION['user_id']; // Get the logged-in user's ID

// Handle form submissions for updating profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = $conn->real_escape_string($_POST['username']);
        $email = $conn->real_escape_string($_POST['email']);
        $conn->query("UPDATE users SET username = '$username', email = '$email' WHERE id = $userId");
        $_SESSION['profile_updated'] = true; // Set session variable to indicate success
        header("Location: profile.php"); // Redirect to refresh page
    }
}

// Close database connection
$conn->close();
?>
