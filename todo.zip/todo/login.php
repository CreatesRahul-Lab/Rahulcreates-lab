<?php
include 'auth.php';

if (is_logged_in()) {
    header("Location: home.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);
    $first_time_login = login($email, $password);

    if ($first_time_login !== false) {
        if ($remember) {
            setcookie('email', $email, time() + (86400 * 30), "/"); // 30 days
            setcookie('password', $password, time() + (86400 * 30), "/"); // 30 days
        }
        if ($first_time_login) {
            header("Location: select_profile.php");
        } else {
            header("Location: home.php");
        }
        exit();
    } else {
        $error = "Invalid email or password";
    }
}

// Check for cookies
if (isset($_COOKIE['email']) && isset($_COOKIE['password'])) {
    $email = $_COOKIE['email'];
    $password = $_COOKIE['password'];
    if (login($email, $password) !== false) {
        header("Location: home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .footer {
            background-color: black;
            color: whitesmoke;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form method="post">
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Password:</label>
            <input type="password" name="password" required>
            <div class="options">
                <label><input type="checkbox" name="remember"> Remember me</label>
                <a href="forgot_password.php">Forgot Password?</a>
            </div>
            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="signup.php">Sign up</a></p>
        <?php if (isset($error)) echo "<p>$error</p>"; ?>
    </div>
</body>
<div class="footer">
        <p>&copy; 2024 Todo App</p> 
   </div>
</html>
